# -*- coding: utf-8 -*-
"""
Created on Sat Jul  2 16:55:42 2022

@author: hehuan
"""

from setuptools import setup,find_packages

setup(
    name='weight_elasticnet',
    version='1.0.0',
    description='The tool for cancer classfication and gene selection',
    url ='https://github.com/huanheaha/Weight_EN.git',
    author="huan he",
    packages = find_packages( )
)
